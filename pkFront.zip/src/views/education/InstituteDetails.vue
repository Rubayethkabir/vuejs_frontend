<template>
  <div class="container">
    <div class="" style="margin-top:5px">
      <img
        src="https://thumbs.dreamstime.com/b/hospital-banner-doctors-staff-14949044.jpg"
        alt=""
        width="100%"
        height="250px"
      />
    </div>
    <section class="py-5">
      <div class="container">
        <h1 class="font-weight-light">Image Slider Two</h1>
        <p class="lead">
          Here you can write anything about the website. These are the sample
          pictures ,replace them and use your own. These pictures are taken from
          unsplash.
        </p>
        <p class="lead">
          Bacon ipsum dolor amet drumstick short loin ribeye sirloin ham spare
          ribs landjaeger, pig turducken meatball sausage. Salami cow shoulder
          pork loin. Meatloaf turducken andouille chuck beef ribs picanha. Filet
          mignon pastrami fatback ribeye leberkas shank boudin sirloin beef
          short ribs tail pig pork loin shoulder buffalo. Short ribs andouille
          swine chicken leberkas. Fatback sirloin pork belly turkey landjaeger
          corned beef biltong, buffalo bresaola strip steak brisket short loin
          salami.
        </p>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: "HospitalDetails",
  data() {
    return {
      msg: "HospitalDetails"
    };
  }
};
</script>
