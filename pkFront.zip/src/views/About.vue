<template>
  <div>
    <p>This is an about page.</p>
  </div>
</template>

<script>
export default {
  components: {
    //
  },

  metaInfo () {
    return { title: this.$t('about') }
  }
}
</script>
