export const APP_NAME = "Amar Pakundia";
